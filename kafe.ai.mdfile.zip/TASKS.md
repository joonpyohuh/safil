# SAFIL — Tasks

## Current Phase
Phase 1 preparation: build the smallest usable MVP after validating the product structure.

## Rule
Work on one task at a time.
Do not start a Next task until the active task is completed and tested.

---

## NOW — Project Foundation

### Task 1. Inspect Existing Repository
- [ ] Read PROJECT.md
- [ ] Read PRODUCT_PRINCIPLES.md
- [ ] Read MVP_SCOPE.md
- [ ] Read DECISIONS.md
- [ ] Inspect current repository structure
- [ ] Summarize what already exists
- [ ] Identify conflicts between current code and these documents
- [ ] Write findings into HANDOFF.md
- [ ] Do not modify implementation code during this task

### Task 2. Propose Technical Architecture
- [ ] Propose folder structure
- [ ] Propose data model
- [ ] Propose auth and storage approach
- [ ] Propose AI generation boundary
- [ ] List required environment variables
- [ ] Identify security and privacy risks
- [ ] Do not implement until the proposal is approved

### Task 3. Build Static Product Shell
- [ ] Responsive app shell
- [ ] Mobile navigation
- [ ] Desktop navigation
- [ ] Home dashboard
- [ ] Empty recent-history section
- [ ] Three primary creation actions
- [ ] No real AI integration yet

---

## NEXT — Core MVP

### Café Profile
- [ ] Build onboarding form
- [ ] Validate required fields
- [ ] Add image upload
- [ ] Persist profile
- [ ] Add edit screen

### Promotional Copy
- [ ] Build purpose selection
- [ ] Build one-line input
- [ ] Build channel selection
- [ ] Define structured AI response schema
- [ ] Generate 3 copy options
- [ ] Show reason for each option
- [ ] Add copy action
- [ ] Save generation history

### Promotional Image
- [ ] Build photo upload
- [ ] Build purpose input
- [ ] Generate or compose 2 options
- [ ] Add editable text overlay
- [ ] Add download action
- [ ] Save generation history

### In-store Notice
- [ ] Add notice type selection
- [ ] Add editable information form
- [ ] Generate café-tone-aligned layout
- [ ] Add print preview
- [ ] Add image download
- [ ] Save generation history

### History
- [ ] List previous generations
- [ ] Filter by output type
- [ ] Open generation detail
- [ ] Reuse previous input
- [ ] Delete an item

---

## LATER
- [ ] Weekly marketing guide
- [ ] Naver Place checklist
- [ ] Transparent report
- [ ] Local event suggestions
- [ ] Billing
- [ ] Usage quota
- [ ] Pilot analytics

---

## Definition of Done
A task is complete only when:
- The implementation matches PROJECT.md and PRODUCT_PRINCIPLES.md
- TypeScript passes
- Lint passes
- Relevant tests pass
- Mobile layout is checked
- Empty, loading, error, and success states are handled
- HANDOFF.md is updated
- TASKS.md is updated
