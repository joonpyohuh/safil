# SAFIL — Decision Log

This file is the source of truth for product and technical decisions.
Do not silently override a recorded decision.

## Status Legend
- Confirmed: use until explicitly changed
- Proposed: may change after review
- Open: requires a decision

---

## 2026-07-19

### Product Name
- Decision: Use **SAFIL** as the working name
- Status: Proposed
- Note: Naming and trademark validation are not complete

### Product Form
- Decision: Build a responsive web app first
- Status: Confirmed
- Reason: Faster pilot testing and no app store dependency

### Primary User
- Decision: Design first for independent café owners with low digital confidence
- Status: Confirmed

### Core Value
- Decision: Prioritize completed outputs over editing tools
- Status: Confirmed

### Publishing
- Decision: Do not auto-publish during MVP
- Status: Confirmed
- Reason: Preserve owner control and reduce platform/API complexity

### Initial Channels
- Decision: Support Instagram and Naver Place first
- Status: Confirmed

### Initial Technical Stack
- Decision:
  - Next.js
  - TypeScript
  - Tailwind CSS
  - Vercel
- Status: Confirmed

### Backend
- Decision: Supabase is the default candidate for auth, database, and file storage
- Status: Proposed
- Action required: Confirm before implementation

### Design Direction
- Decision:
  - Calm, trustworthy, and warm
  - More like a local brand partner than an AI dashboard
  - Avoid excessive gradients, neon AI visuals, dense analytics, and developer-oriented language
- Status: Confirmed

### MVP Output Types
- Decision:
  1. Promotional copy
  2. Promotional image
  3. In-store notice
- Status: Confirmed

### First Pilot
- Decision: 기투커피 로스터스 is the first pilot candidate
- Status: Confirmed

---

## Open Decisions
- [ ] Confirm final name and domain
- [ ] Confirm Supabase
- [ ] Select AI text model
- [ ] Select image generation/editing model
- [ ] Decide whether image output is generated from templates, AI editing, or a hybrid
- [ ] Define pilot consent and data retention policy
- [ ] Define initial pricing only after pilot interviews
